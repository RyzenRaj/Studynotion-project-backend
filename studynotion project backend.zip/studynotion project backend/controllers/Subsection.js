const { findByIdAndUpdate, findByIdAndDelete } = require('../models/Category')
const Section = require('../models/Section')
const Subsection = require('../models/Subsection')
const {uploadImageToCloudinary} = require('../utils/imageUploader')


// create subsection 

exports.createSubSection = async (req,res)=>{
    try {
        // fetch data fom reqbody
        const {sectionId,title,timeDuration,description} =req.body


        //fetch video from body 
        const  video = req.files.videofile


        // vailidation 
        if(!title|| !timeDuration || !description || !video ){
            return res.status(400),json({
                success:false,
                msg:"all fields are required"
            })
        }

        //uplaod video to cloudinary 
        const uploadDeatils  = await uploadImageToCloudinary(video, process.env.FOLDER_NAME);

        // creat a subsection
        const subSectionDetails = await Subsection.create({
            title:title,
            timeDuration:timeDuration,
            description:description,
            videoUrl:uploadDeatils.secure_url
        })


        //update section with subection obj id 
        const updateSection = await Section.findByIdAndUpdate(
            sectionId,
            { $push: { Subsection: subSectionDetails._id } },
            { new: true }
        ).populate('Subsection');

        //return resposne

        return res.status(200).json({
            success:true,
            msg:"subsection created",
            updateSection
        })
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"unable to create sub section please try again",error
            
        })
    }
}

exports.updatesubSection = async (req,res)=>{
    try {
        // data input 
        const {SubsectionId,titile, timeDuration, description, url} = req.body



        // vailidation 
        if(!SubsectionId || !titile || !timeDuration || !description || !url){
            return res.status(400).json({
                success:false,
                msg:"all fields are required"
            })
        }

        // update data
        const updateData = await Section.findByIdAndUpdate({SubsectionId},{titile,timeDuration,description,url} ,{new:true})

        res.status(200).json({
            success:true,
            msg:"section updated successfully"

        })
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"unable to update section please try again",error
            
        })
    }
}



exports.deleteSection = async(req,res)=>{
    try {
        // get id 
        const {subSectionId} = req.body

        // validate and delete
        const del =  await findByIdAndDelete({subSectionId})
        if (!deletedSection) {
            return res.status(404).json({
                success: false,
                msg: "subSection not found"
            });
        } 

        return res.status(200).json({
            success: true,
            msg: "Section deleted successfully",
            deletedSection
        });
        

    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"unable to delete section please try again",error
            
        })
    }
}