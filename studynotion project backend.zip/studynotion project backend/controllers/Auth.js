const User = require('../models/User');
const Otp = require('../models/Otp');
const otpGenerator = require("otp-generator");
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
require("dotenv").config();
const Profile = require("../models/Profile")

// send otp
exports.sendOtp = async (req, res) => {
    try {
        // fetch email from req ki body 
        const { email } = req.body;

        // check if user already exists
        const checkUserPresent = await User.findOne({ email });

        // if user already exists, return an error
        if (checkUserPresent) {
            return res.status(400).json({
                success: false,
                msg: "User already registered",
            });
        }

        // generate OTP
        let otp = otpGenerator.generate(6, {
            upperCaseAlphabets: false,
            lowerCaseAlphabets: false,
            specialChars: false,
        });
        console.log("OTP generated:", otp);

        // check if OTP is unique
        let result = await Otp.findOne({ otp });

        while (result) {
            otp = otpGenerator.generate(6, {
                upperCaseAlphabets: false,
                lowerCaseAlphabets: false,
                specialChars: false,
            });
            result = await Otp.findOne({ otp });
        }

        // save OTP entry in the database
        // const otpPayload = { email, otp };
        const otpPayload = { email, otp };
        const otpEntry = await Otp.create(otpPayload);
        console.log("OTP entry created:", otpEntry);

        // const otpEntry = new Otp(otpPayload);
        // await otpEntry.save();
        // console.log("OTP entry created:", otpEntry);

        // return response
        res.status(200).json({
            success: true,
            msg: "OTP sent successfully",
            otp,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            msg: "Internal server error",
        });
    }
};





// sign up

exports.signUp = async(req,res)=>{
    try {

        //  data fetch from req ki body 
        const{
            firstName,
            lastName,
            email,
            password,
            confirmPassoword,
            accountType,
            contactNumber,
            otp,
        } = req.body



        // validate data

        if(!firstName || !lastName || !email || !password || !confirmPassoword || !otp){
            return res.status(403).json({
                success:false,
                msg:"all feilds are required",
            })
        }


        // 2 pass match krlo 


        if(password !== confirmPassoword){
            return res.status(400).json({
                success:false,
                msg:"password and confirm password doesn't match"
            })
        }

        // check user alredy exist 
        const existUser  = await  User.findOne({email})

        if(existUser){
            return res.status(400).json({
                success:false,
                msg:"user is alredy registered"
            })
        }

        
        // find most recent otp for the user
        const recentOtp = await Otp.findOne({email}).sort({createdAt:-1}).limit(1);
        console.log(recentOtp)

       // validate otp
        if (!recentOtp) {
            return res.status(400).json({
                success: false,
                msg: "otp not found",
            });
        } else if (otp !== recentOtp.otp) {
            return res.status(400).json({
                success: false,
                msg: "invalid otp",
            });
        }


        // hash pass 
        const hashedPassoword = await bcrypt.hash(password,10);


        const profileDetails = await Profile.create({
            gender:null,
            dateOfBirth:null,
            contactNumber:null,
            about:null
        })

        // db entry 
        const user= await User.create({
            firstName,
            lastName,
            email,
            contactNumber,
            password:hashedPassoword,
            accountType,
            additionalDetails: profileDetails._id,
            image:`https://api.dicebear.com/7.x/initials/svg?seed=${firstName}${lastName}`


        })

        //return res

        return res.status(200).json({
            success:true,
            msg:"user is registered succesfully",
            user

        })
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success:false,
            msg:"user not registred please try again "
        })
    }
}

// login

exports.login = async (req,res)=>{
    try {
        // get data from req ki body 
        const {email, password}= req.body
        

        // vailidate
        if(!email || !password){
            return res.status(400).json({
                success:false,
                msg:"please fill all the details",
            })
        }
        

        // user check exist  or not 
      
        
        const user = await User.findOne({email}).populate("additionalDetails");

        console.log(user)
        

        if(!user){
            return res.status(400).json({
                success:false,
                msg:" user is not registered please sign up first"
            })
        }

        
        // token genrate jwt   , after match password 

        let matchPassword = await bcrypt.compare(password, user.password);

        if (matchPassword) {
            const Payload =  {
                email: user.email,
                id:user._id,
                accountType:user.accountType
            }
            const token = jwt.sign(Payload,process.env.JWT_SECRET, { 
                expiresIn:"2h"
            })
            user.token = token
            user.password = undefined;

            // genrate cookie 
            const options = {
                expires:new Date(Date.now()+ 3*24*60*60*1000),
                httpOnly:true
            }

            // name  + value + options
            res.cookie("token", token, options).status(200).json({
                success:true,
                token,
                user,
                msg:"logged in"
            })

            console.log(first)
        } else {
            // Handle case where passwords do not match
            return res.status(401).json({
                success:false,
                msg:"password is incorrect"
            })
        }

        
        // create cookie send res 
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"login error please try again "
        })
        
    }
}




// change passoword
    
exports.changePassword = async (req,res)=>{
    const {oldPassword,newPassword, confirmNewPassoword} = req.body


    if(newPassword !== confirmNewPassoword){
        return res.status(400).json({
            success:true,
            msg:"password doesn't match"

        })
    }
    const user  = req.user 
    
    const isOldPassCorrect = await bcrypt.compare(oldPassword, user.password)

    if(!isOldPassCorrect){
        return res.status(400).json({
            success:false,
            msg:"old pass is wrong"
        })
    }

    // hash password
    const hashedPass =  await bcrypt.hash(newPassword,10);

    // db entry 

    updatePass = await User.findByIdAndUpdate(user._id, { password: hashedPass });

    // send mail
    try {
        
        const mailResponse = await mailSender(user.email, "password is updated" )
    } catch (error) {
        console.log("error while sending", error)
    }

    



}