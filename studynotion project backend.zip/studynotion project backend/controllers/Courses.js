const Course = require('../models/Course')
const Tag = require('../models/Category')
const User = require('../models/User')
const {uploadImageToCloudinary} = require('../utils/imageUploader')

// create course handler
exports.createCourse = async (req,res)=>{
    try {
        
        // data fetch
        const {courseName, courseDescription, whatYouWillLearn, price, tag}= req.body


        // get thumbnail 
        const thumbnail = req.files.thumbnailImage;


        // vailidation 

        if(!courseName || !courseDescription || !whatYouWillLearn || !price || !tag){
            res.status(400).json({
                success:false,
                msg:"all fields are reuired"
            })
        }

        // instructor  check 
        const userId = req.user._id
        const instructorDeatils = await User.findById({userId})

        console.log(instructorDeatils, instructorDeatils)

        if(!instructorDeatils){
            return res.status(404).json({
                success:false,
                msg:"instructor not found"
            })
        }

        // check the tag is vailid 

        // when u get this from users its and id so u need to find the deatils in db with the perticualr id 
        // todo:   sdfkjbhsakhgfhjasdbgjsfhgb
        const tagDetails = await Tag.findById(tag)
        if(!tagDetails){
            return res.status(404).json({
                success:false,
                msg:"tagdetails not found"
            })
        }

        // uplaod image to cloudinary 

        const thumbnailImage = await uploadImageToCloudinary(thumbnail, process.env.FOLDER_NAME)

        // create entry for new course

        const newCourse = await Course.create({
            courseName,
            courseDescription,
            instructor:instructorDeatils._id,
            whatYouWillLearn:whatYouWillLearn,
            price:price,
            tag:tagDetails._id,
            thumbnail:thumbnailImage.secure_url,
        })

        // user update - add the new course to the user schema for instructor
        await User.findByIdAndUpdate(
            { _id: instructorDeatils._id },
            { $push: { courses: newCourse._id } },
            { new: true }
        );

        // tag schema update 
        await Tag.findByIdAndUpdate(
            {_id:tagDetails._id},
            {$push: { course: newCourse._id }},
            {new:true}
        );

        return res.status(200).json({
            success:true,
            msg:"course created successfully",
            data:newCoursecourse
        })


    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"error while creating course"
        })
    }
}

// get all course
exports.showAllCourse =async(req,res)=>{
    try {
        const allCourse = await Course.find({},{courseName, price, tag, thumbnail, instructor, ratingAndReviews, studentEnrolled}).populate("instructor").exec()
        return res.status(200).json({
            success:true,
            msg:"data for all courses fetch successfully"
        })
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success:false,
            msg:error.msg
        })
    }
}


// get course details 

exports.getCourseDetails = async (req, res) => {
    const { course_id } = req.body;

    try {
        const courseDetails = await Course.findById({ _id: course_id })
            .populate({
                path: 'instructor',
                populate: {
                    path: 'additionalDetails'
                }
            })
            .populate('category')
            .populate('ratingAndReviews')
            .populate({
                path: 'courseContent',
                populate: {
                    path: 'subsection'
                }
            })
            .exec();

        if (!courseDetails ) {
            return res.status(404).json({
                success: false,
                msg: 'Course not found'
            });
        }

        return res.status(200).json({
            success: true,
            msg: 'Course details retrieved successfully',
            courseDetails
        });

    } catch (error) {
        return res.status(500).json({
            success: false,
            msg: 'Error retrieving course details',
            error
        });
    }
};
