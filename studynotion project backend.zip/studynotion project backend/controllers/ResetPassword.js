const User = require('../models/User')
const mailsender = require('../utils/mailSender');
const mailSender = require('../utils/mailsender');
const bcrypt = require('bcrypt')

// reset password token
exports.resetPasswordToken = async (req, res)=>{
    try {
            //  fetch email from req body 

        const {email} = req.body;



        //check user , email vailidation
        const user = await User.findOne({email: email})
        if(!user){
            return res.status(400).json({
                success:false,
                msg:"Your email is not registered with us"
            })
        }

        // genrate token

        const token  = crypto.randomUUID();


        // update user by adding token and expires time 
        const updatedDeatils = await User.findOneAndUpdate({email:email},{
            token:token,
            resetPassowordExpires:Date.now() + 5*60*1000,
        },
        {new:true})



        //  create url 

        const url = `http://localhost:3000/update-password/${token}`

        // send mail  with url 

        await mailSender(email , "password reset link", `password reset link: ${url}`)

        // res
        return res.json({
            success:true,
            msg:"email sent successfully change u r pass"
        })
    
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success:false,
            msg:"something went wrong while send the link for the password "
        })
    }

}




// resetPassword


exports.resetPassword = async (req,res)=>{
    try {
        // data fetch 

        const {password, confirmPassword, token} = req.body 

        //vailidation
        if(password !== confirmPassword){
            return res.status(400).json({
                success:true,
                msg:"pwd doesn't match"
            })
        }

        //get user deatils  from db using token 
        const userDetails =  await User.findOne({token:token})

        
        // if no entry  - invalid token 
        if(!userDetails){
            return res.status(400).josn({
                success:false,
                msg:"token is invailid"
            })
        }

        // token time check 
        if (userDetails.resetPassowordExpires < Date.now()) {
            return res.status(400).json({
                success: false,
                msg: "token is expired"
            });
        }
        

        // pass hash 
        const hashpass = await bcrypt.hash(password, 10);


        // pass upadte
        await User.findOneAndUpdate(
            {token:token},
            {password:hashpass},
            {new:true}


        )

        //res return 
        return res.status(200).json({
            success: true,
            msg: "pass reset successfull"
        });
    } catch (error) {
        return res.status(400).json({
            success: false,
            msg: "error while resetting pass"
        });
    }
}