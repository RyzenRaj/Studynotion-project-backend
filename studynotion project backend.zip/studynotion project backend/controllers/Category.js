const category= require('../models/Category')

exports.createCategory=  async(req,res)=>{
    try {
        // data fetch 
        const{name, description}= req.body

        if(!name || !description){
            return res.status(400).json({
                success:false,
                msg:"all feilds are required"
            })
        }

        // create entry in db
        const categoryDetails = await category.create({
            name:name,
            description:description
        })
        console.log(categoryDetails)

        return  res.status(200).json({
            success:true,
            msg:"category created succesfully"
        })
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:error.msg
        })
    }
}

// get all categorys 

exports.showAllCategory= async(req,res)=>{
    try {
        const allcategorys = await category.find({}, {name:true, description:true})

        res.status(200).json({
            success:true,
            msg:"All categorys returned successfully ",
            allcategorys,
        })
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:error.msg
        })
    }
}

// category page deatils
exports.categoryDeatils = async (req,res)=>{
    try {
        // get category id 
        const {categoryId} = req.body 
    
        // get course for specified cat id 
        const selectCatcourse = await category.findById({categoryId}).populate("courses").exec();


        // vailidate
        if(!selectCatcourse){
            return res.status(404).json({
                success:false,
                msg:"no data found"
            })
        } 
        // get course for diff cat 
        const differentCat = await category.find({_id:{$ne:categoryId}}).populate("courses").exec();


        // get top 10 selling course 
        // HW ->     
        // return course 

        return res.status(200).json({
            success:true,
            data:{
                selectCatcourse,
                differentCat      
            }        
        })

    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:error.msg
        })
    }
}