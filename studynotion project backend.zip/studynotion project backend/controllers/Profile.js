const User = require('../models/User')
const Profile = require('../models/Profile')
const {uploadImageToCloudinary} = require("../utils/imageUploader")


exports.updateProfile = async(req,res)=>{
    try {
        // get data 
        const {gender, dateOfBirth, about, ContactNumber} = req.body
        const userId = req.user.id
        // validate data
        if(!gender || ! dateOfBirth || !about || !ContactNumber){
            return res.status(400).json({
                success:false,
                msg:"all fields required"

            })
        }

        // here we get user id 
        const userDetails  = await User.findById(userId).populate('additionalDetails') 
        // profile id find 
        const profileId = userDetails.additionalDetails;


        const profileDetails= await Profile.findById(profileId);

        // update profile
        // here object is already made so use save function
        profileDetails.dateOfBirth;
        profileDetails.gender = gender
        profileDetails.ContactNumber = ContactNumber
        profileDetails.about = about

        await profileDetails.save();

        if(profileDetails){
            return res.status(400).json({
                success:false,
                msg:"details not updated"
            })
        }

        // return res
        return res.status(200).json({
            success:true,
            msg:"profile updated successfully",
            profileDetails

        })
    } catch (error) {
        return res.status(400).json({
            success:false,
            msg:error
        })
    }
}


//delte accont  + profile 

// explore cron job  - how can we schedule the req
exports.deleteAccount = async (req,res)=>{
    try {
            // get id 
        const id  = req.user.id
        // validation
        const userDetails = await User.findById(id)
        if(!userDetails) {
            return res.status(400).json({
                success:false,
                msg:"user not found"
            })
        }
        // delete profile 
        await Profile.findByIdAndDelete({_id:userDetails.additionalDetails})
        
        // hw --> enrolled count  - 1

        //delete user
        await User.findByIdAndDelete({_id:id});

        return res.status(200).json({
            success:true,
            msg:"user deleted"
        })
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"user cant deleted"
        })
    }
}


// get all users

exports.getAllUserDetails = async (req,res)=>{
    try {
        // get id
        const id  = req.user.id
        // vailidate the user deatils
        const userDetails = await User.findById(id).populate("additionalDetails").exec();


        if(!userDetails){
            return res.status(500).json({
                success:false,
                msg:"no data available for this user"
            })
            
        }
        // return res
        return res.status(200).json({
            success:true,
            msg:"here u r info ",
            userDetails
        })
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"error while getting the info of user"
        })
    }
}

const checkExtension = (allowedExtensions, extension) => {
    return allowedExtensions.includes(extension);
};

exports.updateDisplayPicture = async (req, res) => {
    try {
        // const { name, email, tags } = req.body;
        const userId = req.user.id;
        const file = req.files.displayPicture;
        console.log(file);

        const extension = file.name.split(".")[1].toLowerCase();
        const allowedExtensions = ["jpeg", "jpg", "png"];
        const isValidExtension = checkExtension(allowedExtensions, extension);

        if (!isValidExtension) {
            return res.status(400).json({ msg: "File format is not supported" });
        }

        const response = await uploadImageToCloudinary(file, "codeHelp");
        console.log(response);

        const imageUrl = response.secure_url; // Define imageUrl here

        try {
            const updatedUser = await User.findOneAndUpdate(
                { _id: userId },
                { $set: { image: imageUrl } },
                { new: true }
            );

            if (!updatedUser) {
                console.error('User not found');
                // Handle the case where the user is not found
            }

            console.log('display picture updated successfully:', updatedUser);

            return res.status(200).json({ msg: "File uploaded successfully" });
        } catch (error) {
            return res.status(500).json({ msg: "Internal server error while uploading", error });
        }
    } catch (error) {
        console.error('Error:', error);
        return res.status(500).json({ msg: "Internal server error", error });
    }
};

    