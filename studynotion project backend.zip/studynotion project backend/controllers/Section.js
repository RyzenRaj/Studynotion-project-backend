const Section = require('../models/Section')
const Course = require('../models/Course')
const { findByIdAndDelete } = require('../models/Category')

exports.createSection =async(req,res)=>{
    try {
        // data fetch

        const {sectionName, courseId}= req.body


        // validate
        if(!sectionName || !courseId){
            return res.status(400).json({
                success:false,
                msg:"all fields are required"
            })
        }

        //create section 
        const newSection = await Section.create({sectionName})



        // update Course section
        // const updatedCourse = await Course.findByIdAndUpdate({courseId},{$push:{courseContent:newSection._id}.populate },{new:true})
        const updatedCourse = await Course.findByIdAndUpdate(
            courseId,
            { $push: { courseContent: newSection._id } },
            { new: true }
        ).populate('courseContent');

        //return response
        return res.status(200).json({
            success:true,
            msg:"section created successfully",
            updatedCourse
        })

    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"unable to update section please try again",error
            
        })
    }
}



exports.updateSection = async (req,res)=>{
    try {
        // data input 
        const {sectionName, sectionId} = req.body



        // vailidation 
        if(!sectionName || !sectionId){
            return res.status(400).json({
                success:false,
                msg:"all fields are required"
            })
        }

        // update data
        const updateData = await Section.findByIdAndUpdate({sectionId},{sectionName} ,{new:true})


        //here we no need to update the course schema coz we can only update the name of section so id will be same 

        res.status(200).json({
            success:true,
            msg:"section updated successfully"

        })
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"unable to update section please try again",error
            
        })
    }
}



exports.deleteSection = async(req,res)=>{
    try {
        // get id 
        const {sectionId} = req.body

        // validate and delete
        const del =  await findByIdAndDelete({sectionId})
        if (!deletedSection) {
            return res.status(404).json({
                success: false,
                msg: "Section not found"
            });
        } 

        return res.status(200).json({
            success: true,
            msg: "Section deleted successfully",
            deletedSection
        });
        // todo  - do we need to delete the entry from course schema 

    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"unable to delete section please try again",error
            
        })
    }
}