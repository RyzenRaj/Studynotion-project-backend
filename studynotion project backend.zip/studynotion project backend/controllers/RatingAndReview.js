const RatingAndReviews = require("../models/ratingAndReviews")
const Course = require('../models/Course');
const ratingAndReviews = require("../models/ratingAndReviews");
const { default: mongoose } = require("mongoose");


// create rating 

exports.createRating = async(req,res)=>{
    try {
        // fetch data
        const {rating, course_id, review} = req.body
        const user_id = req.user.user_id;

        // check if user is enrolled or not 
        const courseDetials = await Course.findOne(
                                    {_id:course_id,
                                    studentEnrolled: {$elemMatch: {$eq: user_id}}}) 


        if(!courseDetials){
            return res.status(400).json({
                success:false,
                msg:"no deatils found "
            })
        }

        //  check exisiting review and rating by user


        const alreadyReview = await RatingAndReviews.findOne({user:user_id, course:course_id});

        if(alreadyReview){
            return res.status(403).josn({
                success:false,
                msg:"alredy reviewed"
            })
        }

        
        // create entry in db for rating and review
        const ratingReview = await ratingAndReviews.create({rating, review, course:course_id, user:user_id})

        // course update 
        const updatedCourseDetails = await Course.findByIdAndUpdate({ _id:course_id},{$push:{ratingAndReviews:ratingReview._id}},{new:true})
        
        console.log(updatedCourseDetails)

        // return res
        return res.status(200).json({
            success:true,
            msg:"ratingandreviews are created",
            ratingReview
        })

        console.log(55)

        
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success:false,
            msg:error
        })
    }    

}


// get average rating
exports.getAverageRating = async (req,res)=>{
    try {
        // get course id
        const courseId = req.body.courseId;
        // average
        const result = await RatingAndReviews.aggregate([
            {
                $match: {
                    // here courseId is string so convert into object
                    course: mongoose.Types.ObjectId(courseId),
                },
            },
            {
                $group: {
                    // here we want to group but dont have the condition so choose null
                    _id: null,
                    averageRating: { $avg: "$rating" },
                },
            },
        ]);

        if(result.length > 0){
            return res.status(200).json({
                stuccess:true,
                // here aggregate returns an arruy so returned 1st index of an array 
                averageRating:result[0].averageRating,
            })
        }

        // if no exist 
        return res.status(200).json({
            stuccess:true,
            averageRating:0            
        })
        //  reutrn avg
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:error
        })
    }
}

// get all rating and reviews from all course 


exports.getAllRating = async (req,res)=>{
    try {
        const allReviews = await ratingAndReviews.find({}).sort({rating:"desc"}.populate({path:"user",select:"firstName lastName email image"})).populate({path:"course", select:"courseName"})
        return res.status(200).json({
            success:true,
            msg:"all reviews fetch successfully",
            allReviews

        })
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:error
        })
    }
}