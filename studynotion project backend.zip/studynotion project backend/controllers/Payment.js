const { mongoose } = require('mongoose')
const {instance}  = require('../config/razorpay')
const Course = require("../models/Course")
const User = require("../models/User")
const mailSender = require('../utils/mailsender')



// caputre the payment initiate the razorpay order 

exports.capture  = async  (req,res)=>{
    // get course id and user 

    const{course_id} = req.body
    const userId = req.user.id



    //vlilidate     
    // vaild course id  coursedetails 
    if(!course_id){
        return res.json({
            success:false,
            msg:"please provide valid course id "
        })
    }

    // vailidate course deatils 
    let course;

    try {
        course = await Course.findById(course_id)
        if(!course){
            return res.json({
                success:false,
                msg:"coudn't find the course"
            })
        }
        // user already pay for the same course
        // here the user id is in string form so we have to conert user id into object id 

        const uid  = new mongoose.Types.ObjectId(userId)
        if(course.studentEnrolled.includes(uid)){
            return res.status(200).json({
                success:false,
                msg:"student is alredy enrolled"
            })
        }


    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success:false,
            msg:error,
        })
    }


    // order create 
    const amount  = course.price
    const currency = "INR";
    

    const options = {
        amount: amount * 100,
        currency,
        // receipt: Math.random(Date.now().toString(),notes:{course:course_id,userId})
        receipt: {
            id: Math.random().toString(),
            notes: {
                course: course_id,
                userId: userId
            }
        }
        
    }

    // order create
    try {
        // initiate the payment using razor pay 
        const paymentResponse = await instance.orders.create(options)
        console.log(paymentResponse);
        return res.status(200).json({
            success:true,
            courseName:course.courseName,
            coursedes:course.courseDescription,
            coursethmbnail:course.thumbnail,
            orderId:paymentResponse.id,
            currency:paymentResponse.currency,
            amount:paymentResponse.amount
        })
    } catch (error) {
        console.log(error)
        res.json({
            success:false,
            msg:"could not initalte the order"
        })
    }

    // and return response


}


// verfiy signature razaor pay and server

exports.verifySignature= async (req,res)=>{
    const webhookSecrct = "123456";
    // when razaor pay hits the webhook for authorizatio then it ll send u the singure in req.headers
    const signature = req.headers("x-razorpay-signature")
    // signatue is hashed 

    // hmac - hashed based msg authenthication code its a combination  1-hash algo 2-secret key 
    // sha - secure hashing algo  - convert the into fixed linght encrypt cant be decrypted 

    const shasum =  crypto.createHmac("sha256", webhookSecrct);

    // hamc obj convert into string
    shasum.update(JSON.stringify(req.body))

    // when u run hashing algo on perticular input and then the output comes and this output called as **digest  hexadecimal format 
    const digest = shasum.digest("hex");

    // with the help of above process we converted this webhooksecret into digest

    // signature and digest match 

    if(signature === digest){
        console.log("payment is authorized")


        // here the main thing is the req is come form razorpay not from frontend so we dont have course and user id here amd  we need to take action -  action is like map course and user with their ids so user got the course coz payment is done but the thign is u need to have course and user id for that but we know that we sended the notes with the payment so  we get that obj and then map coz payement is done and signature is verified
        const {course_id, userId} =req.body.payload.payment.entity.notes

        try {
            //fullfill the action

            //find the course enroll the student 
            const enrollCourse = Course.findOneAndUpdate(
                { _id: course_id },
                { $push: { studentEnrolled: userId } },
                { new: true }
            );

            if(enrollCourse){
                return res.status(500).json({
                    success:false,
                    msg:"course not found ",
                })
            }
            console.log(enrollCourse)


            // find the student and upadte course
            const enrollCourseStudent = User.findOneAndUpdate(
                { _id: userId },
                { $push: { courses: course_id } },
                { new: true }
            );

            if(enrollCourse){
                return res.status(500).json({
                    success:false,
                    msg:"course not added ",
                })
            }
            console.log(enrollCourseStudent)



            //send mail  confirmation
            
            const emailResponse = await mailSender(enrollCourseStudent.email," congratulations" ,"new course enrolled")

            console.log(emailResponse)
            return res.status(200).json({
                success:true,
                msg:"course enrolled and mail send successfully "
            })

            
              
        } catch (error) {
            console.log(error)
            return res.sattus(500).json({
                success:false,
                msg:error
            })
        }


    }
    else{
        return res.status(400).json({
            success:false,
            msg:"signature invailid"
        })
    }








}
