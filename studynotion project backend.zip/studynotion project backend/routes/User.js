const express = require('express');
const router = express.Router();
const {auth} = require("../middlewares/auth")



const {sendOtp, signUp, login , changePassword} = require('../controllers/Auth')



router.post('/sendotp',sendOtp);
router.post('/signUp',signUp);
router.post('/login',login);
router.post('/changePassword',changePassword);


module.exports = router;