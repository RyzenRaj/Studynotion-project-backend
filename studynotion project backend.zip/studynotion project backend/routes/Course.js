const express = require('express');
const router = express.Router();


const {createCourse,showAllCourse,getCourseDetails} = require("../controllers/Courses")
const {createCategory,showAllCategory,categoryDeatils} = require("../controllers/Category")
const {createRating,getAverageRating,getAllRating} = require("../controllers/RatingAndReview")
const {auth,isInstructor , isStudent , isAdmin} =require("../middlewares/auth")
const {createSection, updateSection, deleteSection} =require("../controllers/Section")
const {createSubSection, updatesubSection } = require("../controllers/Subsection")

 

router.post("/createCourse",auth,isInstructor,createCourse)
router.get("/showAllCourse",showAllCourse)
router.get("/getCourseDetails",getCourseDetails)

// section
router.post("/createSection",auth, isInstructor,createSection)
router.post("/updateSection",auth, isInstructor,updateSection)
router.post("/deleteSection",auth, isInstructor,deleteSection)



// subsection
router.post("/createSubSection",auth, isInstructor,createSubSection)
router.post("/updatesubSection",auth, isInstructor,updatesubSection)


// category
router.post("/createCategory"/auth,isInstructor,createCategory);
router.get("/showAllCategory"/showAllCategory);
router.get("/categoryDeatils"/categoryDeatils);


// rating and review
router.post("/createRating",auth, isStudent,createRating)
router.get("/getAverageRating",getAverageRating)
router.get("/getAllRating",getAllRating)



module.exports = router;
