const express = require('express');
const router = express.Router();


const {capture , verifySignature}  = require("../controllers/Payment")
const {auth, isStudent,isInstructor, isAdmin} = require("../middlewares/auth")
router.post("/capture",auth, isStudent,capture);
router.post("/verifySignature",verifySignature);


module.exports = router;