const mongoose = require("mongoose")

const sectionSchema = new mongoose.Schema({
    SectionName:{
        type:"String",

    },
    Subsection:[
        {
            type:mongoose.Schema.Types.ObjectId,
            requierd:true,
            ref:"Subsection"
        }
    ],
    

})

module.exports = mongoose.model("Section", sectionSchema);