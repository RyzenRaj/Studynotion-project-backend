const mongoose = require("mongoose")

const courseSchema = new mongoose.Schema({
    courseName:{
        type:"String",
        trim:true
    },
    courseDescription:{
        type:"String",
        trim:true,
    },
    instructor:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User",
        required:true,


    },
    whatYouWillLearn:{
        type:"String"
    },
    courseContent:[
        {
            type:mongoose.Schema.Types.ObjectId,
            ref:"Section"

        }
    ],
    ratingAndReviews:[
        {
            type:mongoose.Schema.Types.ObjectId,
            ref:"RatingAndReviews"
        }
    ],
    price:{
        type:Number,
    },
    thumbnail:{
        type:"Stirng",
    },
    thumbnail: {
        type: "String", // Corrected the type to String
    },
    category:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"Category"
    },
    studentEnrolled:[{
        type:mongoose.Schema.Types.ObjectId,
        requierd:true,
        ref:"User"
    }]

})

module.exports = mongoose.model("Course", courseSchema);