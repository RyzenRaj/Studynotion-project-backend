const jwt = require('jsonwebtoken')
require('dotenv').config();
const User = require('../models/User')

// auth 
exports.auth = async(req,res,next)=>{
    try {
        // extreact code 

        const token  = req.cookies.token || req.body.token || req.header("Authorisation").replace("Bearer ", "")
        // if token missing 

        if(!token){
            return res.status(400).json({
                success:false,
                msg:"token missing"
            })
        }

        // verfify token 
         
        try {
            const decode =  jwt.verify(token, process.env.JWT_SECRET)
            console.log(decode)

            req.user = decode;

        } catch (error) {
            // vefication issue 
            res.status(401).json({
                success:false,
                msg:"token is invalid"
            })
        }
        next();
    } catch (error) {
        return res.status(401).json({
            success:false,
            msg:"something went wrong while vailidating the token"
        })
    }
}


// isStudent


exports.isStudent = async(req,res,next)=>{
    try {
        if(req.user.accountType !== "Student"){
            return res.status(401).json({
                success:false,
                msg:"this is a protected route for student only"
            })
        }
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"user role cannot be verified"
        })
    }
}


// isInstructor
exports.isInstructor = async(req,res,next)=>{
    try {
        if(req.user.accountType !== "isInstructor"){
            return res.status(401).json({
                success:false,
                msg:"this is a protected route for isInstructor only"
            })
        }
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"user role cannot be verified"
        })
    }
}

// isAdmin
exports.isAdmin = async(req,res,next)=>{
    try {
        if(req.user.accountType !== "isAdmin"){
            return res.status(401).json({
                success:false,
                msg:"this is a protected route for isAdmin only"
            })
        }
    } catch (error) {
        return res.status(500).json({
            success:false,
            msg:"user role cannot be verified"
        })
    }
}
